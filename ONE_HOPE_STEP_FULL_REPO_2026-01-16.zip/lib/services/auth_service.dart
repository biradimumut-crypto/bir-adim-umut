import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import '../models/user_model.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dart:math';
import 'notification_service.dart';
import 'package:intl/intl.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Mevcut Firebase Auth kullanıcısı
  User? get currentFirebaseUser => _auth.currentUser;
  
  /// Firestore instance (dış erişim için)
  FirebaseFirestore get firestore => _firestore;
  
  /// Bonus adım formatlama (örn: 200000 -> "200.000")
  String _formatBonusSteps(int steps) {
    return NumberFormat.decimalPattern('tr').format(steps);
  }

  /// Benzersiz 6 karakterli kişisel referral kodu oluştur
  Future<String> _generateUniquePersonalReferralCode() async {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Karışıklık yaratabilecek 0,O,1,I hariç
    final random = Random();
    
    while (true) {
      final code = List.generate(6, (_) => chars[random.nextInt(chars.length)]).join();
      
      // Bu kodun kullanılıp kullanılmadığını kontrol et
      final existing = await _firestore
          .collection('users')
          .where('personal_referral_code', isEqualTo: code)
          .limit(1)
          .get();
      
      if (existing.docs.isEmpty) {
        return code;
      }
    }
  }

  /// Eski kullanıcılar için kişisel referral kodu oluştur ve kaydet
  Future<String?> ensurePersonalReferralCode(String userId) async {
    try {
      final userDoc = await _firestore.collection('users').doc(userId).get();
      
      if (!userDoc.exists) return null;
      
      final userData = userDoc.data();
      final existingCode = userData?['personal_referral_code'];
      
      // Zaten kod varsa, onu döndür
      if (existingCode != null && existingCode.toString().isNotEmpty) {
        return existingCode;
      }
      
      // Yoksa yeni kod oluştur ve kaydet
      final newCode = await _generateUniquePersonalReferralCode();
      
      await _firestore.collection('users').doc(userId).update({
        'personal_referral_code': newCode,
        'referral_count': userData?['referral_count'] ?? 0,
      });
      
      return newCode;
    } catch (e) {
      print('Error ensuring personal referral code: $e');
      return null;
    }
  }

  /// Kişisel referral kodunu uygula (email doğrulama sonrası)
  /// Bonus adım kazandırır ve davet edene de bonus verir
  Future<Map<String, dynamic>> applyReferralCode(String code) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) {
        return {'success': false, 'error': 'Oturum açmanız gerekiyor'};
      }

      final userId = currentUser.uid;
      final upperCode = code.toUpperCase();

      // Kodu doğrula - sahibini bul
      final referrerQuery = await _firestore
          .collection('users')
          .where('personal_referral_code', isEqualTo: upperCode)
          .limit(1)
          .get();

      if (referrerQuery.docs.isEmpty) {
        return {'success': false, 'error': 'Geçersiz kod'};
      }

      final referrerDoc = referrerQuery.docs.first;
      final referrerId = referrerDoc.id;

      // Kendi kodunu mu girdi?
      if (referrerId == userId) {
        return {'success': false, 'error': 'Kendi kodunuzu kullanamazsınız'};
      }

      // Kullanıcı zaten davet edilmiş mi?
      final userDoc = await _firestore.collection('users').doc(userId).get();
      if (userDoc.data()?['referred_by'] != null) {
        return {'success': false, 'error': 'Zaten bir davet kodu kullandınız'};
      }

      // Bonus miktarları
      const int newUserBonus = 200000; // Yeni kullanıcı 200.000 bonus adım
      const int referrerBonus = 50000; // Davet eden 50.000 bonus adım

      // Batch ile güncelle
      final batch = _firestore.batch();

      // Yeni kullanıcının bilgilerini güncelle
      batch.update(_firestore.collection('users').doc(userId), {
        'referred_by': referrerId,
        'referral_bonus_steps': FieldValue.increment(newUserBonus),
      });

      // Davet edenin bilgilerini güncelle
      batch.update(_firestore.collection('users').doc(referrerId), {
        'referral_count': FieldValue.increment(1),
        'referral_bonus_steps': FieldValue.increment(referrerBonus),
      });

      await batch.commit();

      return {
        'success': true,
        'message': '${_formatBonusSteps(newUserBonus)} bonus adım kazandınız!',
        'bonusSteps': newUserBonus,
      };
    } catch (e) {
      print('applyReferralCode hatası: $e');
      return {'success': false, 'error': 'Bir hata oluştu'};
    }
  }

  /// Basit Kayıt Ol (Referral kodları sonra sorulacak)
  Future<Map<String, dynamic>> signUpSimple({
    required String fullName,
    required String email,
    required String password,
  }) async {
    try {
      // 1. Firebase Auth'ta kullanıcı oluştur
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final userId = userCredential.user!.uid;
      print('✅ [KAYIT] Firebase Auth kullanıcısı oluşturuldu: $userId');

      // 2. Yeni kullanıcı için benzersiz kişisel referral kodu oluştur
      final newUserReferralCode = await _generateUniquePersonalReferralCode();

      // 3. User koleksiyonunda yeni belge oluştur (email_verified: false ile)
      final maskedName = UserModel.maskName(fullName);
      final userData = {
        'full_name': fullName,
        'full_name_lowercase': fullName.toLowerCase(),
        'masked_name': maskedName,
        'nickname': null,
        'email': email,
        'email_verified': false, // Kod ile doğrulanacak
        'profile_image_url': null,
        'wallet_balance_hope': 0.0,
        'current_team_id': null,
        'theme_preference': 'light',
        'created_at': Timestamp.now(),
        'last_step_sync_time': null,
        'device_tokens': [],
        'personal_referral_code': newUserReferralCode,
        'referred_by': null,
        'referral_count': 0,
        'referral_bonus_steps': 0,
      };

      await _firestore.collection('users').doc(userId).set(userData);
      print('✅ [KAYIT] User belgesi oluşturuldu: $userId');

      // 4. Email doğrulama KODU gönder (Cloud Function ile)
      try {
        final functions = FirebaseFunctions.instance;
        final callable = functions.httpsCallable('sendVerificationCode');
        await callable.call();
        print('✅ [KAYIT] Email doğrulama kodu gönderildi: $email');
      } catch (e) {
        print('⚠️ Email doğrulama kodu gönderilemedi: $e');
      }

      return {
        'success': true,
        'userId': userId,
        'email': email,
        'personalReferralCode': newUserReferralCode,
        'message': 'Kayıt başarılı!',
        'requiresEmailVerification': true,
      };
    } on FirebaseAuthException catch (e) {
      return {
        'success': false,
        'error': _getFirebaseErrorMessage(e.code),
      };
    } catch (e) {
      print('❌ Kayıt hatası: $e');
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  /// Kayıt Ol (Referral Code ile) - DEPRECATED, signUpSimple kullanın
  /// 
  /// NOT: Bu fonksiyon artık kullanılmıyor. Referral kodları kayıt sonrası
  /// dialog ile alınıp processReferralCodesForSocialLogin ile işleniyor.
  @Deprecated('signUpSimple kullanın, referral kodları kayıt sonrası dialog ile alınıyor')
  Future<Map<String, dynamic>> signUpWithReferral({
    required String fullName,
    required String email,
    required String password,
    String? referralCode, // Takım referral kodu
    String? personalReferralCode, // Kişisel referral kodu
  }) async {
    User? createdUser;
    try {
      // 1. Firebase Auth'ta kullanıcı oluştur
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      createdUser = userCredential.user;
      final userId = createdUser!.uid;
      print('✅ [KAYIT] Firebase Auth kullanıcısı oluşturuldu: $userId');

      // 2. Takım referral code varsa takımı bul
      String? targetTeamId;
      if (referralCode != null && referralCode.isNotEmpty) {
        print('🔍 Takım referral kodu aranıyor: ${referralCode.toUpperCase()}');
        
        final teamQuery = await _firestore
            .collection('teams')
            .where('referral_code', isEqualTo: referralCode.toUpperCase())
            .limit(1)
            .get();

        if (teamQuery.docs.isNotEmpty) {
          targetTeamId = teamQuery.docs[0].id;
          print('✅ Takım bulundu: $targetTeamId');
        } else {
          print('❌ Takım bulunamadı: ${referralCode.toUpperCase()}');
        }
      }

      // 3. Kişisel referral code varsa davet edeni bul (sadece kaydet, bonus sonra verilecek)
      String? referrerUserId;
      if (personalReferralCode != null && personalReferralCode.isNotEmpty) {
        print('🔍 Kişisel referral kodu aranıyor: ${personalReferralCode.toUpperCase()}');
        
        final referrerQuery = await _firestore
            .collection('users')
            .where('personal_referral_code', isEqualTo: personalReferralCode.toUpperCase())
            .limit(1)
            .get();

        if (referrerQuery.docs.isNotEmpty) {
          referrerUserId = referrerQuery.docs.first.id;
          print('✅ Davet eden bulundu: $referrerUserId');
        } else {
          print('❌ Kişisel referral kodu bulunamadı: ${personalReferralCode.toUpperCase()}');
        }
      }

      // 4. Yeni kullanıcı için benzersiz kişisel referral kodu oluştur
      final newUserReferralCode = await _generateUniquePersonalReferralCode();

      // 5. User koleksiyonunda yeni belge oluştur
      final maskedName = UserModel.maskName(fullName);
      final userData = {
        'full_name': fullName,
        'full_name_lowercase': fullName.toLowerCase(),
        'masked_name': maskedName,
        'nickname': null,
        'email': email,
        'profile_image_url': null,
        'wallet_balance_hope': 0.0,
        'current_team_id': targetTeamId,
        'theme_preference': 'light',
        'created_at': Timestamp.now(),
        'last_step_sync_time': null,
        'device_tokens': [],
        // Kişisel Referral Alanları
        'personal_referral_code': newUserReferralCode,
        'referred_by': referrerUserId,
        'referral_count': 0,
        'referral_bonus_steps': 0,
      };

      await _firestore.collection('users').doc(userId).set(userData);
      print('✅ [KAYIT] User belgesi oluşturuldu: $userId');

      // 6. Takım referral code varsa, team_members'a ekle (BONUS YOK - sonra verilecek)
      if (targetTeamId != null) {
        print('🔄 [KAYIT] Takıma ekleniyor: $targetTeamId');
        final teamDoc = _firestore.collection('teams').doc(targetTeamId);
        
        await teamDoc.collection('team_members').doc(userId).set({
          'team_id': targetTeamId,
          'user_id': userId,
          'member_status': 'active',
          'join_date': Timestamp.now(),
          'member_total_hope': 0.0,
          'member_daily_steps': 0,
        });

        final teamData = (await teamDoc.get()).data();
        final memberIds = List<String>.from(teamData?['member_ids'] ?? []);
        memberIds.add(userId);

        await teamDoc.update({
          'members_count': FieldValue.increment(1),
          'member_ids': memberIds,
        });
        
        print('✅ [KAYIT] Takıma üye olarak eklendi: $targetTeamId');
      }
      
      return {
        'success': true,
        'userId': userId,
        'teamId': targetTeamId,
        'referrerUserId': referrerUserId,
        'personalReferralCode': newUserReferralCode,
        'message': 'Kayıt başarılı!',
      };
    } on FirebaseAuthException catch (e) {
      // Auth hatası durumunda kullanıcıyı sil (rollback)
      if (createdUser != null) {
        try {
          await createdUser.delete();
          print('🗑️ Kayıt hatası: Auth kullanıcısı silindi (rollback)');
        } catch (deleteError) {
          print('⚠️ Auth kullanıcısı silinemedi: $deleteError');
        }
      }
      return {
        'success': false,
        'error': _getFirebaseErrorMessage(e.code),
      };
    } catch (e) {
      // Genel hata durumunda kullanıcıyı sil (rollback)
      print('❌ Kayıt hatası: $e');
      if (createdUser != null) {
        try {
          await createdUser.delete();
          print('🗑️ Kayıt hatası: Auth kullanıcısı silindi (rollback)');
        } catch (deleteError) {
          print('⚠️ Auth kullanıcısı silinemedi: $deleteError');
        }
      }
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  /// Referral bonus adımlarını kullanıcıya ekle (Süresiz - users koleksiyonunda)
  Future<void> _addReferralBonusSteps(String userId, int bonusSteps, String dateStr, String otherUserId, String? otherUserName) async {
    // Kullanıcı dökümanına süresiz bonus ekle
    await _firestore.collection('users').doc(userId).update({
      'referral_bonus_steps': FieldValue.increment(bonusSteps),
    });

    // Activity log ekle
    final now = Timestamp.now();
    
    // User subcollection
    await _firestore.collection('users').doc(userId).collection('activity_logs').add({
      'user_id': userId,
      'activity_type': 'referral_bonus',
      'bonus_steps': bonusSteps,
      'other_user_id': otherUserId,
      'other_user_name': otherUserName,
      'created_at': now,
      'timestamp': now,
    });
    
    // Global activity_logs
    await _firestore.collection('activity_logs').add({
      'user_id': userId,
      'activity_type': 'referral_bonus',
      'bonus_steps': bonusSteps,
      'other_user_id': otherUserId,
      'other_user_name': otherUserName,
      'created_at': now,
      'timestamp': now,
    });
  }

  /// Giriş Yap
  Future<Map<String, dynamic>> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = userCredential.user;
      if (user == null) {
        return {
          'success': false,
          'error': 'Giriş başarısız',
        };
      }

      // Email doğrulama kontrolü - Firestore'dan (Kod sistemi)
      final userDoc = await _firestore.collection('users').doc(user.uid).get();
      final isEmailVerified = userDoc.data()?['email_verified'] == true;
      
      if (!isEmailVerified) {
        // Oturumu kapat ama email bilgisini döndür
        await _auth.signOut();
        return {
          'success': false,
          'error': 'email-not-verified',
          'email': email,
        };
      }

      // Günlük aktif kullanıcı için last_login_at güncelle
      await _firestore.collection('users').doc(user.uid).update({
        'last_login_at': FieldValue.serverTimestamp(),
      });
      
      // FCM token'ı güncelle
      await NotificationService().updateFcmTokenAfterLogin();

      return {'success': true};
    } on FirebaseAuthException catch (e) {
      return {
        'success': false,
        'error': e.code,
      };
    } catch (e) {
      // Firebase Auth hatalarını yakala
      if (e.toString().contains('user-not-found')) {
        return {
          'success': false,
          'error': 'user-not-found',
        };
      } else if (e.toString().contains('wrong-password')) {
        return {
          'success': false,
          'error': 'wrong-password',
        };
      } else if (e.toString().contains('invalid-credential')) {
        // invalid-credential: şifre yanlış veya kullanıcı yok olabilir
        return {
          'success': false,
          'error': 'invalid-credential',
        };
      }
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  /// Email ile kayıtlı kullanıcı var mı kontrolü (Firestore'dan)
  Future<bool> checkIfUserExists(String email) async {
    try {
      final normalizedEmail = email.toLowerCase().trim();
      final query = await _firestore
          .collection('users')
          .where('email', isEqualTo: normalizedEmail)
          .limit(1)
          .get();
      return query.docs.isNotEmpty;
    } catch (e) {
      print('checkIfUserExists hatası: $e');
      return false;
    }
  }

  /// Çıkış Yap
  Future<void> signOut() async {
    await _auth.signOut();
  }

  /// Şifre Sıfırla
  Future<Map<String, dynamic>> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      return {'success': true};
    } on FirebaseAuthException catch (e) {
      return {
        'success': false,
        'error': _getFirebaseErrorMessage(e.code),
      };
    }
  }

  /// Mevcut Kullanıcıyı Al
  Future<UserModel?> getCurrentUser() async {
    try {
      final uid = _auth.currentUser?.uid;
      if (uid == null) return null;

      final doc = await _firestore.collection('users').doc(uid).get();
      if (!doc.exists) return null;

      return UserModel.fromFirestore(doc);
    } catch (e) {
      print('Mevcut kullanıcı al hatası: $e');
      return null;
    }
  }

  /// Google/Apple ile kayıt sonrası referral kodlarını işle
  /// Bu metod, social login sonrası referral dialog'dan çağrılır
  Future<Map<String, dynamic>> processReferralCodesForSocialLogin({
    required String userId,
    String? teamReferralCode,
    String? personalReferralCode,
  }) async {
    try {
      String? targetTeamId;
      String? referrerUserId;
      int totalBonusSteps = 0;

      // 1. Takım referral kodu varsa takımı bul ve kullanıcıyı ekle
      if (teamReferralCode != null && teamReferralCode.isNotEmpty) {
        final teamQuery = await _firestore
            .collection('teams')
            .where('referral_code', isEqualTo: teamReferralCode.toUpperCase())
            .limit(1)
            .get();

        if (teamQuery.docs.isNotEmpty) {
          final teamDoc = teamQuery.docs.first;
          targetTeamId = teamDoc.id;

          // Kullanıcıyı takıma ekle
          await _firestore.collection('users').doc(userId).update({
            'current_team_id': targetTeamId,
          });

          // Team member olarak ekle
          final userDoc = await _firestore.collection('users').doc(userId).get();
          final userData = userDoc.data();
          final userFullName = userData?['full_name'] ?? 'Kullanıcı';
          final userMaskedName = userData?['masked_name'] ?? userFullName;
          
          await _firestore
              .collection('teams')
              .doc(targetTeamId)
              .collection('team_members')
              .doc(userId)
              .set({
            'user_id': userId,
            'display_name': userMaskedName,
            'joined_at': Timestamp.now(),
            'role': 'member',
            'member_total_hope': 0.0,
            'member_daily_steps': 0,
          });

          final teamData = teamDoc.data();
          final teamName = teamData['team_name'] ?? 'Takım';
          final teamLeaderId = teamData['leader_uid'] ?? teamData['created_by'];
          final memberIds = List<String>.from(teamData['member_ids'] ?? []);
          memberIds.add(userId);

          await _firestore.collection('teams').doc(targetTeamId).update({
            'members_count': FieldValue.increment(1),
            'member_ids': memberIds,
          });

          // Takım referral bonusu
          const teamReferralBonus = 100000;
          await _firestore.collection('teams').doc(targetTeamId).update({
            'team_bonus_steps': FieldValue.increment(teamReferralBonus),
          });
          await _firestore.collection('users').doc(userId).update({
            'referral_bonus_steps': FieldValue.increment(teamReferralBonus),
          });
          
          final now = Timestamp.now();
          
          // 1️⃣ Yeni üyenin aktivite geçmişi: "X takımına katıldınız ve 100.000 bonus adım kazandınız"
          // User subcollection
          await _firestore.collection('users').doc(userId).collection('activity_logs').add({
            'user_id': userId,
            'activity_type': 'team_join_bonus',
            'bonus_steps': teamReferralBonus,
            'team_id': targetTeamId,
            'team_name': teamName,
            'created_at': now,
            'timestamp': now,
          });
          // Global
          await _firestore.collection('activity_logs').add({
            'user_id': userId,
            'activity_type': 'team_join_bonus',
            'bonus_steps': teamReferralBonus,
            'team_id': targetTeamId,
            'team_name': teamName,
            'created_at': now,
            'timestamp': now,
          });
          
          // 2️⃣ Yeni üyenin aktivite geçmişi: "X takımınıza 100.000 adım kazandırdınız"
          // User subcollection
          await _firestore.collection('users').doc(userId).collection('activity_logs').add({
            'user_id': userId,
            'activity_type': 'team_contribution_bonus',
            'bonus_steps': teamReferralBonus,
            'team_id': targetTeamId,
            'team_name': teamName,
            'created_at': now,
            'timestamp': now,
          });
          // Global
          await _firestore.collection('activity_logs').add({
            'user_id': userId,
            'activity_type': 'team_contribution_bonus',
            'bonus_steps': teamReferralBonus,
            'team_id': targetTeamId,
            'team_name': teamName,
            'created_at': now,
            'timestamp': now,
          });
          
          // 3️⃣ Takım liderinin aktivite geçmişi: "X kullanıcı takımınıza 100.000 adım kazandırdı"
          if (teamLeaderId != null && teamLeaderId != userId) {
            // User subcollection (takım lideri için)
            await _firestore.collection('users').doc(teamLeaderId).collection('activity_logs').add({
              'user_id': teamLeaderId,
              'activity_type': 'team_new_member_bonus',
              'bonus_steps': teamReferralBonus,
              'team_id': targetTeamId,
              'team_name': teamName,
              'new_member_id': userId,
              'new_member_name': userFullName,
              'created_at': now,
              'timestamp': now,
            });
            // Global
            await _firestore.collection('activity_logs').add({
              'user_id': teamLeaderId,
              'activity_type': 'team_new_member_bonus',
              'bonus_steps': teamReferralBonus,
              'team_id': targetTeamId,
              'team_name': teamName,
              'new_member_id': userId,
              'new_member_name': userFullName,
              'created_at': now,
              'timestamp': now,
            });
          }
          
          // Global activity_logs - team_referral_bonus (admin özet istatistikleri için)
          await _firestore.collection('activity_logs').add({
            'user_id': userId,
            'team_id': targetTeamId,
            'activity_type': 'team_referral_bonus',
            'bonus_steps': teamReferralBonus,
            'team_name': teamName,
            'created_at': now,
            'timestamp': now,
          });
          
          totalBonusSteps += teamReferralBonus;
        }
      }

      // 2. Kişisel referral kodu varsa davet edeni bul
      if (personalReferralCode != null && personalReferralCode.isNotEmpty) {
        final referrerQuery = await _firestore
            .collection('users')
            .where('personal_referral_code', isEqualTo: personalReferralCode.toUpperCase())
            .limit(1)
            .get();

        if (referrerQuery.docs.isNotEmpty) {
          referrerUserId = referrerQuery.docs.first.id;
          final referralBonus = 100000;
          final today = DateTime.now();
          final dateStr = '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';

          // Her iki tarafa bonus ekle
          await _addReferralBonusSteps(referrerUserId, referralBonus, dateStr, userId, null);
          await _addReferralBonusSteps(userId, referralBonus, dateStr, referrerUserId, null);

          // Davet edenin referral_count'unu artır
          await _firestore.collection('users').doc(referrerUserId).update({
            'referral_count': FieldValue.increment(1),
          });

          // Davet edilenin referred_by alanını güncelle
          await _firestore.collection('users').doc(userId).update({
            'referred_by': referrerUserId,
          });

          totalBonusSteps += referralBonus;
        }
      }

      String message = '';
      if (targetTeamId != null && referrerUserId != null) {
        message = 'Takıma katıldınız ve ${_formatBonusSteps(totalBonusSteps)} bonus adım kazandınız!';
      } else if (targetTeamId != null) {
        message = 'Takıma katıldınız ve 100.000 bonus adım kazandınız!';
      } else if (referrerUserId != null) {
        message = '100.000 bonus adım kazandınız!';
      }

      return {
        'success': true,
        'teamId': targetTeamId,
        'referrerUserId': referrerUserId,
        'totalBonusSteps': totalBonusSteps,
        'message': message,
        'teamReferralApplied': targetTeamId != null,
        'personalReferralApplied': referrerUserId != null,
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  /// Firebase Hata Kodlarını Döndür (çeviri language_provider'da yapılacak)
  String _getFirebaseErrorMessage(String code) {
    // Hata kodunu döndür, çeviri UI'da yapılacak
    return code;
  }

  /// Kullanıcı Oturum Açtı mı?
  Stream<User?> get authStateChanges {
    return _auth.authStateChanges();
  }

  /// Mevcut Kullanıcı UID'sini Al
  String? getCurrentUserId() {
    return _auth.currentUser?.uid;
  }

  /// Google ile Giriş/Kayıt
  /// Eğer kullanıcı daha önce kayıtlı değilse otomatik kayıt yapar
  Future<Map<String, dynamic>> signInWithGoogle() async {
    try {
      final GoogleSignIn googleSignIn = GoogleSignIn(
        scopes: ['email', 'profile'],
      );

      // Google ile oturum aç
      final GoogleSignInAccount? googleUser = await googleSignIn.signIn();
      
      if (googleUser == null) {
        return {
          'success': false,
          'error': 'GOOGLE_SIGN_IN_CANCELLED',
        };
      }

      // Google kimlik bilgilerini al
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;

      // Firebase credential oluştur
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // Firebase ile giriş yap
      final UserCredential userCredential = await _auth.signInWithCredential(credential);
      final user = userCredential.user;

      if (user == null) {
        return {
          'success': false,
          'error': 'Kullanıcı bilgisi alınamadı.',
        };
      }

      // Kullanıcı Firestore'da var mı kontrol et
      final userDoc = await _firestore.collection('users').doc(user.uid).get();

      if (!userDoc.exists) {
        // Yeni kullanıcı - otomatik kayıt yap
        final fullName = user.displayName ?? 'Kullanıcı';
        final maskedName = UserModel.maskName(fullName);
        
        // Kişisel referral kodu oluştur
        final personalReferralCode = await _generateUniquePersonalReferralCode();

        await _firestore.collection('users').doc(user.uid).set({
          'full_name': fullName,
          'full_name_lowercase': fullName.toLowerCase(), // Arama için lowercase
          'masked_name': maskedName,
          'nickname': null,
          'email': user.email,
          'profile_image_url': user.photoURL,
          'wallet_balance_hope': 0.0,
          'current_team_id': null,
          'theme_preference': 'light',
          'created_at': Timestamp.now(),
          'last_login_at': Timestamp.now(), // Günlük aktif için
          'last_step_sync_time': null,
          'device_tokens': [],
          'auth_provider': 'google',
          'personal_referral_code': personalReferralCode,
          'referral_count': 0,
        });
        
        // FCM token'ı güncelle
        await NotificationService().updateFcmTokenAfterLogin();

        return {
          'success': true,
          'isNewUser': true,
          'message': 'Google ile başarıyla kayıt oldunuz!',
        };
      }

      // Mevcut kullanıcı - last_login_at güncelle
      await _firestore.collection('users').doc(user.uid).update({
        'last_login_at': FieldValue.serverTimestamp(),
      });
      
      // FCM token'ı güncelle
      await NotificationService().updateFcmTokenAfterLogin();

      return {
        'success': true,
        'isNewUser': false,
        'message': 'Google ile giriş yapıldı!',
      };
    } on FirebaseAuthException catch (e) {
      return {
        'success': false,
        'error': _getFirebaseErrorMessage(e.code),
      };
    } catch (e) {
      return {
        'success': false,
        'error': 'Google girişi sırasında hata: $e',
      };
    }
  }

  /// Apple ile Giriş/Kayıt
  /// Eğer kullanıcı daha önce kayıtlı değilse otomatik kayıt yapar
  Future<Map<String, dynamic>> signInWithApple() async {
    try {
      // Apple Sign In provider
      final appleProvider = AppleAuthProvider();
      appleProvider.addScope('email');
      appleProvider.addScope('name');

      // Firebase ile Apple girişi yap
      final UserCredential userCredential = await _auth.signInWithProvider(appleProvider);
      final user = userCredential.user;

      if (user == null) {
        return {
          'success': false,
          'error': 'Kullanıcı bilgisi alınamadı.',
        };
      }

      // Kullanıcı Firestore'da var mı kontrol et
      final userDoc = await _firestore.collection('users').doc(user.uid).get();

      if (!userDoc.exists) {
        // Yeni kullanıcı - otomatik kayıt yap
        final fullName = user.displayName ?? 'Apple Kullanıcısı';
        final maskedName = UserModel.maskName(fullName);
        
        // Kişisel referral kodu oluştur
        final personalReferralCode = await _generateUniquePersonalReferralCode();

        await _firestore.collection('users').doc(user.uid).set({
          'full_name': fullName,
          'full_name_lowercase': fullName.toLowerCase(), // Arama için lowercase
          'masked_name': maskedName,
          'nickname': null,
          'email': user.email,
          'profile_image_url': user.photoURL,
          'wallet_balance_hope': 0.0,
          'current_team_id': null,
          'theme_preference': 'light',
          'created_at': Timestamp.now(),
          'last_login_at': Timestamp.now(), // Günlük aktif için
          'last_step_sync_time': null,
          'device_tokens': [],
          'auth_provider': 'apple',
          'personal_referral_code': personalReferralCode,
          'referral_count': 0,
        });
        
        // FCM token'ı güncelle
        await NotificationService().updateFcmTokenAfterLogin();

        return {
          'success': true,
          'isNewUser': true,
          'message': 'Apple ile başarıyla kayıt oldunuz!',
        };
      }

      // Mevcut kullanıcı - last_login_at güncelle
      await _firestore.collection('users').doc(user.uid).update({
        'last_login_at': FieldValue.serverTimestamp(),
      });
      
      // FCM token'ı güncelle
      await NotificationService().updateFcmTokenAfterLogin();

      return {
        'success': true,
        'isNewUser': false,
        'message': 'Apple ile giriş yapıldı!',
      };
    } on FirebaseAuthException catch (e) {
      return {
        'success': false,
        'error': _getFirebaseErrorMessage(e.code),
      };
    } catch (e) {
      return {
        'success': false,
        'error': 'Apple girişi sırasında hata: $e',
      };
    }
  }

  /// Google/Apple kullanıcısına e-posta/şifre ile giriş ekleme
  /// Bu, sosyal login kullanıcılarının e-posta/şifre ile de giriş yapabilmesini sağlar
  Future<Map<String, dynamic>> createPasswordForSocialUser({
    required String password,
  }) async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        return {
          'success': false,
          'error': 'Kullanıcı oturumu bulunamadı',
        };
      }

      final email = user.email;
      if (email == null || email.isEmpty) {
        return {
          'success': false,
          'error': 'E-posta adresi bulunamadı',
        };
      }

      // E-posta/şifre credential oluştur ve mevcut hesaba bağla
      final credential = EmailAuthProvider.credential(
        email: email,
        password: password,
      );

      await user.linkWithCredential(credential);

      // Firestore'da auth_provider'a 'email' ekle
      await _firestore.collection('users').doc(user.uid).update({
        'has_password': true,
        'auth_provider': 'email', // Artık e-posta ile de giriş yapabilir
      });

      return {
        'success': true,
        'message': 'Şifre başarıyla oluşturuldu! Artık e-posta ve şifre ile de giriş yapabilirsiniz.',
      };
    } on FirebaseAuthException catch (e) {
      if (e.code == 'provider-already-linked') {
        return {
          'success': false,
          'error': 'Bu hesapta zaten bir şifre tanımlı.',
        };
      } else if (e.code == 'credential-already-in-use') {
        return {
          'success': false,
          'error': 'Bu e-posta başka bir hesapla ilişkili.',
        };
      } else if (e.code == 'weak-password') {
        return {
          'success': false,
          'error': 'Şifre çok zayıf. En az 6 karakter olmalı.',
        };
      }
      return {
        'success': false,
        'error': _getFirebaseErrorMessage(e.code),
      };
    } catch (e) {
      return {
        'success': false,
        'error': 'Şifre oluşturma hatası: $e',
      };
    }
  }

  /// Kullanıcının şifresi var mı kontrol et
  Future<bool> hasEmailPasswordProvider() async {
    final user = _auth.currentUser;
    if (user == null) return false;
    
    return user.providerData.any((provider) => provider.providerId == 'password');
  }

  /// Email doğrulama mailini tekrar gönder (BUG-004)
  Future<Map<String, dynamic>> resendVerificationEmail() async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        return {
          'success': false,
          'error': 'Kullanıcı bulunamadı',
        };
      }

      if (user.emailVerified) {
        return {
          'success': false,
          'error': 'Email zaten doğrulanmış',
        };
      }

      final actionCodeSettings = ActionCodeSettings(
        url: 'https://bir-adim-umut-yeni.web.app/email-verified.html',
        handleCodeInApp: false,
      );
      await user.sendEmailVerification(actionCodeSettings);
      return {
        'success': true,
        'message': 'Doğrulama maili gönderildi',
      };
    } catch (e) {
      return {
        'success': false,
        'error': 'Mail gönderilemedi: $e',
      };
    }
  }

  /// Re-authenticate kullanıcı (hassas işlemler için) (BUG-006)
  Future<Map<String, dynamic>> reauthenticate(String password) async {
    try {
      final user = _auth.currentUser;
      if (user == null || user.email == null) {
        return {
          'success': false,
          'error': 'Kullanıcı bulunamadı',
        };
      }

      final credential = EmailAuthProvider.credential(
        email: user.email!,
        password: password,
      );

      await user.reauthenticateWithCredential(credential);
      return {'success': true};
    } on FirebaseAuthException catch (e) {
      if (e.code == 'wrong-password' || e.code == 'invalid-credential') {
        return {
          'success': false,
          'error': 'Şifre yanlış',
        };
      }
      return {
        'success': false,
        'error': _getFirebaseErrorMessage(e.code),
      };
    } catch (e) {
      return {
        'success': false,
        'error': 'Doğrulama hatası: $e',
      };
    }
  }

  /// Hesap silme - Cloud Function çağırır (BUG-006)
  /// Apple/Google/GDPR zorunluluğu
  Future<Map<String, dynamic>> deleteAccount() async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        return {
          'success': false,
          'error': 'Kullanıcı bulunamadı',
        };
      }

      // Cloud Function'ı çağır
      final callable = FirebaseFunctions.instance.httpsCallable('deleteAccount');
      final result = await callable.call();

      if (result.data['success'] == true) {
        // Local olarak da çıkış yap
        await _auth.signOut();
        return {
          'success': true,
          'message': result.data['message'] ?? 'Hesap silindi',
        };
      } else {
        return {
          'success': false,
          'error': result.data['error'] ?? 'Hesap silinemedi',
        };
      }
    } on FirebaseFunctionsException catch (e) {
      String errorMessage;
      switch (e.code) {
        case 'unauthenticated':
          errorMessage = 'Oturum açmanız gerekiyor';
          break;
        case 'not-found':
          errorMessage = 'Kullanıcı bulunamadı';
          break;
        case 'internal':
          errorMessage = 'Sunucu hatası. Lütfen tekrar deneyin.';
          break;
        default:
          errorMessage = e.message ?? 'Hesap silinemedi';
      }
      return {
        'success': false,
        'error': errorMessage,
      };
    } catch (e) {
      return {
        'success': false,
        'error': 'Hesap silme hatası: $e',
      };
    }
  }
}
